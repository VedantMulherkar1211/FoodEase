import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
// import {Link} from 'react-router-dom';
import Navbar from '../NavBar/navbar';
function AdminHome()
{
  return(
    <div className='container'>
      <div className='row'>
   <Navbar/>
   </div>
   
   </div>
  );
}

export default AdminHome;