import React from 'react';
import {Link} from 'react-router-dom';
import Navbar from '../NavBar/navbar';
function DeliveryHome()
{
  return(
    <div className='container'>
      <div className='row'>
   <Navbar/>
   </div>
   </div>
  );
}

export default DeliveryHome;