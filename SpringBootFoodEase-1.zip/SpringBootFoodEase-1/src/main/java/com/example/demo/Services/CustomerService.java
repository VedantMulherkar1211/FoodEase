package com.example.demo.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entities.Customer;
import com.example.demo.Repositories.CustomerRepo;


@Service
public class CustomerService {
	@Autowired
	CustomerRepo crepo;
	public Customer saveCustomer(Customer c)
	{
		return crepo.save(c);
	}
}
