package com.example.demo.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repositories.RoleRepo;

@Service
public class RoleService {
	@Autowired
	RoleRepo rrepo;

}
