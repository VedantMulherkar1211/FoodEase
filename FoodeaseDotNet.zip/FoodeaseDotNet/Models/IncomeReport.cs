﻿namespace FoodeaseDotNet.Models
{
    public class IncomeReport
    {
        public int RestaurantId { get; set; }
        public string RestaurantName { get; set; }
        public decimal TotalPayments { get; set; }
    }
}
